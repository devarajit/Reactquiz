import * as Permissions  from 'expo-permissions';
import { Notifications } from 'expo';


import * as firebase from 'firebase'

let config = {
 apiKey: "AIzaSyB3Kzu07cRkDDXeDQMJJcT4xFhuZgjfr7o",
    authDomain: "connext-b08aa.firebaseapp.com",
    databaseURL: "https://connext-b08aa.firebaseio.com",
    projectId: "connext-b08aa",
    storageBucket: "",
    messagingSenderId: "528012979704",
    appId: "1:528012979704:web:fefe3bd8e60d890b"
};
if(firebase.apps.length==0){
firebase.initializeApp(config);
}

 export default (async function sendPushNotification(userID) {
   alert("send notificayio "+userID)
   var token='';
    var ref = firebase.database().ref('bankusers/');
     
    
     try{
    firebase.database().ref('users/' + userID).once('value').then(function(snapshot) {
                         token = (snapshot.val() && snapshot.val().token)
      }); 
     }catch(error){
       console.log(error);
     }
    console.log("send :"+token)
    const message = {
      to: token,
      sound: 'default',
      title: 'conneXt',
      body: 'Welcome to conneXt!!! Hakuna Matata!!!',
      data: { data: {
        title:'Welcome to conneXt... Hakuna Matata!!!',
        notificationid:0
       } },
    };
    const response = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Accept-encoding': 'gzip, deflate',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(message),
    })
 });