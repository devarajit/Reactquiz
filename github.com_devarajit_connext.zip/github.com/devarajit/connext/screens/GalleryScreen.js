import Gallery from 'react-native-image-gallery';
import React from 'react';
import * as firebase from 'firebase'
export default class ErrorScreen extends React.Component {
  constructor(props) {
   super(props);
   this.state =
   {
       loading: true,
       mounted: true,
       image: "/images/logoblue.jpg",
       url: "",
   }
}
async getAndLoadHttpUrl() {
   if (this.state.mounted == true) {
     const ref = firebase.storage().ref(this.props.image);
     ref.getDownloadURL().then(data => {
        this.setState({ url: data })
        this.setState({ loading: false })
     }).catch(error => {
        this.setState({ url: "../assets/logo.jpg" })
        this.setState({ loading: false })
    })
  }
}
componentDidMount() {
    
   this.getAndLoadHttpUrl()
}
componentWillUnmount() {
   this.setState({ isMounted: false })
}
  render() {
    return (
      <Gallery
        style={{ flex: 1, backgroundColor: 'black' }}
        images={[
          { source: require('../assets/logo.png'), dimensions: { width: 150, height: 150 } },
          { source: { uri: 'http://i.imgur.com/XP2BE7q.jpg' } },
          { source: { uri: 'http://i.imgur.com/5nltiUd.jpg' } },
          { source: { uri: 'http://i.imgur.com/6vOahbP.jpg' } },
          { source: { uri: 'http://i.imgur.com/kj5VXtG.jpg' } }
        ]}
      />
    );
  }
}