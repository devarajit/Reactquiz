import React from 'react';
import { Text,TouchableOpacity, StyleSheet,View,ScrollView,FlatList,Image,ImageBackground} from 'react-native'

import { List, ListItem, Button,Header } from 'react-native-elements';
import '@expo/vector-icons';
import firebase from 'firebase'
import Wallpaper from './Wallpaper'
let config = {
 apiKey: "AIzaSyB3Kzu07cRkDDXeDQMJJcT4xFhuZgjfr7o",
    authDomain: "connext-b08aa.firebaseapp.com",
    databaseURL: "https://connext-b08aa.firebaseio.com",
    projectId: "connext-b08aa",
    storageBucket: "",
    messagingSenderId: "528012979704",
    appId: "1:528012979704:web:fefe3bd8e60d890b"
};
if(firebase.apps.length==0){
firebase.initializeApp(config);
}

export default class NotificationsScreen extends React.Component {
   static navigationOptions = {
    drawerLabel: 'Notifications',
    drawerIcon: (tintcolor) => (
      <Image
        source={{uri: `https://dummyimage.com/60x60/000/fff.jpg&text=2`}}
        style={{width: 30, height: 30, borderRadius: 15}}
      />
    )
  }
  constructor(props) {
    super(props);

    this.state = {
      selected: (new Map(): Map<String,boolean>),
      user: props.currentUser,
      notification: {},
      userID: '',
      notificationsAvailable: [],
      error: '',
      loading:false,
    };

  }

  componentDidMount() {
    let notificationPath = 'users/' + firebase.auth().currentUser.uid + '/notifications/';
    try{
    Promise.apply(firebase.database().ref(notificationPath).orderByKey().on('value', (snapshot) => {
      console.log("test:"+snapshot.val())
    
      const array=Object.values(snapshot.val());
      this.setState({
        notificationsAvailable: array
      });
    
    }));
    }catch(error){
      console.log(error);
    }
      console.log("Length"+this.state.notificationsAvailable.length)
    

  }
_onPressItem = (id: string) => {
    // updater functions are preferred for transactional updates
    this.setState((state) => {
      // copy the map rather than modifying state.
      const selected = new Map(state.selected);
      selected.set(id, !selected.get(id)); // toggle
      return {selected};
    });
  };
keyExtractor = (item, index) => index.toString()

renderItem = ({ item }) => (
  <TouchableOpacity containerStyle={{ borderBottomWidth: 0 }}
    id={item.eventid}
    title={item.data.notificationid}
    selected={!!this.state.selected.get(item.id)}
    subtitle={item.data.title}
    OnPressItem={this._pressItem}

  />
)


 renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: "86%",
          backgroundColor: "#CED0CE",
          marginLeft: "14%"
        }}
      />
    );
  }
render () {
  return (
     <ImageBackground source={require('../assets/connext_bg.png')} style={{ width: '100%',
        height: '100%',
        flex: 1} }  resizeMode='cover' >
        <View>
              
                  <Header
                leftComponent={{ icon: 'menu', color: '#fff',          
                onPress:this.props.navigation.openDrawer }}
                centerComponent={{text:"Notifications"  }}
                rightComponent={{ icon: 'home', color: '#fff' }}
              />
  
          <FlatList
            keyExtractor={this.keyExtractor}
            data={this.state.notificationsAvailable}
            renderItem={this.renderItem}
            ItemSeparatorComponent={()=>this.renderSeparator}
          />
        </View>
    </ImageBackground>
  )}
  }