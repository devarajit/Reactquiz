
import React from 'react';
import {
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Text,
  KeyboardAvoidingView,
  View,Image,ScrollView,ImageBackground,Dimensions
} from 'react-native';
import PropTypes from 'prop-types';
import * as firebase from 'firebase'
import { Icon, SafeAreaView,Header,Left } from 'react-native-elements';
import { Notifications } from 'expo';
import * as Permissions from 'expo-permissions';
import QRCodeGenerator from './QRCodeGenerator'

export default class HomeScreen extends React.Component {
  componentDidMount(){
    console.log("get Profile");
    () => this.getProfile();
    console.log("after profile")
  }
  constructor(props)
	{
		super(props);
		this.state={ 
      currentUser:props.currentUser,
      user: {
        first_name:'',
        last_name:'',
        profile_id:'',
        user_id:'',
        last_logged_in:'',
    }};

    
    }
  static navigationOptions = {
    drawerLabel: 'Home',
    drawerIcon: (tintcolor) => (
      <Image
        source={{uri: `https://dummyimage.com/60x60/000/fff.jpg&text=1`}}
        style={{width: 30, height: 30, borderRadius: 15}}
      />
    )
  }
  getProfile=() =>{
     Promise.apply(firebase.database().ref('users/'+firebase.auth().currentUser.uid).once("value", function(snapshot){
         console.log(snapshot.val().eventuser);
         
         {(profile_id)=>this.setState(snapshot.val().profile_picture)}
         {(first_name)=>this.setState(snapshot.val().first_name)}
         {(last_name)=>this.setState(snapshot.val().last_name)}
         {(last_logged_in)=>this.setState(snapshot.val().last_logged_in)}
         {(user_id)=>this.setState(snapshot.val().eventuser)}
     }));

     alert(this.state.first_name);
     
  }
  render(){
    
      return(
         <ImageBackground source={require('../assets/connext_bg.png')} style={ styles.imgBackground }  resizeMode='cover' >
        <View style ={styles.container}>
          <Image source={require('../assets/logo.png')} style={{width:100, height:100}}/> 
            <Header
          leftComponent={{ icon: 'menu', color: '#fff',          
           onPress:this.props.navigation.openDrawer }}
          centerComponent={{ text:"Home", style: { color: '#fff' } }}
          rightComponent={{ icon: 'home', color: '#fff' }}
        />
          <View style={{flex:1,alignItems:'center' ,justifyContent:'center', padding:10,}}>
            <Text>  Welcome {this.state.first_name} {this.state.last_name} !!!
            </Text>
            <QRCodeGenerator userId={this.state.user_id}
          />
        </View>
        </View>
        </ImageBackground>
      );
    
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  imgBackground: {
        width: '100%',
        height: '100%',
        flex: 1 
},
});