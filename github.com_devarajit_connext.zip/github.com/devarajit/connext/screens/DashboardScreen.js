import React, { Component } from 'react';
import { View, Text, StyleSheet, Button,ScrollView,Image,Dimensions,Platform,I18nManager,ImageBackground  } from 'react-native';
import {createAppContainer, createDrawerNavigator,DrawerItems, NavigationEvents, NavigationActions,SafeAreaView} from 'react-navigation'
import HomeScreen from './HomeScreen'
import { Container, Content, Icon, Header, Body } from 'native-base'

import NotificationsScreen  from './NotificationsScreen'
import SignoutScreen from './SignoutScreen'
import LinksScreen from './LinksScreen'
import registerForPushNotificationsAsync from '../app/registerForPushNotificationsAsync';
import ErrorScreen from './ErrorScreen'
import GalleryScreen from './GalleryScreen'
const{width}=Dimensions.get('window');
import * as firebase from 'firebase'

let config = {
 apiKey: "AIzaSyB3Kzu07cRkDDXeDQMJJcT4xFhuZgjfr7o",
    authDomain: "connext-b08aa.firebaseapp.com",
    databaseURL: "https://connext-b08aa.firebaseio.com",
    projectId: "connext-b08aa",
    storageBucket: "",
    messagingSenderId: "528012979704",
    appId: "1:528012979704:web:fefe3bd8e60d890b"
};
if(firebase.apps.length==0){
firebase.initializeApp(config);
}

class DashboardScreen extends Component {
  componentDidMount(){
    
   }
  constructor(props){
    super(props);
    this.state=props;
  }
   
  render() {
    
    return (
     
    <AppContainerNavigator />

    );
  }
}

const CustomDrawerComponent = (props) =>(

 <Container>
    <Header style={styles.drawerHeader}>
      <Body>
        <Image
          style={styles.drawerImage}
          source={require('../assets/Connext_X_Logo.png')} />
      </Body>
    </Header>
    <Content>
      <DrawerItems {...props} />
    </Content>

  </Container>

);




const AppDrawerNavigator = createDrawerNavigator({
  Home: {
    screen: (props) => <HomeScreen  {...props}/>
  },
  Notifications: {
    screen: (props)=> <NotificationsScreen {...props}/>
  },
  Gallery:{
    screen:  (props)=><GalleryScreen {...props}/>
  },
  SignOut :{
    screen: (props)=><SignoutScreen {...props}/>
  }
},{
   initialRouteName: 'Home',
    drawerPosition: 'left',
    contentComponent:CustomDrawerComponent,
    drawerOpenRoute: 'DrawerOpen',
    drawerCloseRoute: 'DrawerClose',
    drawerToggleRoute: 'DrawerToggle'
 
});
const AppContainerNavigator = createAppContainer(AppDrawerNavigator);

const styles = StyleSheet.create({
  drawerHeader: {
    height: 200,
    backgroundColor: 'white'
  },
  drawerImage: {
    height: 150,
    width: 150,
    borderRadius: 75
  }

})
export default DashboardScreen;