import React, { Component } from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';
import * as firebase from 'firebase';
class SignoutScreen extends Component {
  render() {
    return (
      <View style={styles.container}>
       
        <Button title="Sign out" onPress={() => firebase.auth().signOut()} />
      </View>
    );
  }
}
export default SignoutScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  }
});