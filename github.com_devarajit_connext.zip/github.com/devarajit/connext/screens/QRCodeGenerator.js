import React from 'react';
import { StyleSheet, Text, View,Button,TextInput } from 'react-native';
import axios from 'axios';
import QRCode from 'react-native-qrcode';
//import QrcodeDecoder from 'qrcode-decoder';


export default class QRCodeGenerator extends React.Component {
	
	render(){
		return (
			<View style={styles.container}>
				{/* <Text>QR Code Scanner</Text> */}
					<QRCode
						value={this.props.userId}
						size={200}
						bgColor='black'
						fgColor='white'
					/>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	container: {
		// backgroundColor: 'green',
		flex: 1,
		alignItems: 'center',
		justifyContent: 'center',
	}
});