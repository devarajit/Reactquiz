import React, { Component } from 'react';
import { View, Text, StyleSheet, Button, TextInput,Image,ImageBackground ,TouchableHighlight} from 'react-native';
import * as Google from 'expo-google-app-auth';
import logoImg from '../assets/logo.png';
import * as firebase from 'firebase'
import Wallpaper from './Wallpaper'
import Logo from './Logo'
import registerForPushNotificationsAsync from '../app/registerForPushNotificationsAsync';
import sendPushNotification from '../app/sendPushNotification'
let config = {
 apiKey: "AIzaSyB3Kzu07cRkDDXeDQMJJcT4xFhuZgjfr7o",
    authDomain: "connext-b08aa.firebaseapp.com",
    databaseURL: "https://connext-b08aa.firebaseio.com",
    projectId: "connext-b08aa",
    storageBucket: "",
    messagingSenderId: "528012979704",
    appId: "1:528012979704:web:fefe3bd8e60d890b"
};
if(firebase.apps.length==0){
firebase.initializeApp(config);
}



class LoginScreen extends Component {
  state= {
    bankid:'',
  };

  isUserEqual = (googleUser, firebaseUser) => {
    if (firebaseUser) {
      var providerData = firebase.providerData;
      for (var i = 0; i < providerData.length; i++) {
        if (
          providerData[i].providerId ===
            firebase.auth.GoogleAuthProvider.PROVIDER_ID &&
          providerData[i].uid === googleUser.getBasicProfile().getId()
        ) {
          // We don't need to reauth the Firebase connection.
          return true;
        }
      }
    }
    return false;
  };
  onSignIn = (googleUser,bankid) => {
    console.log(
      'Google Auth Response',
      googleUser 
    );
    // We need to register an Observer on Firebase Auth to make sure auth is initialized.
    var unsubscribe = firebase.auth().onAuthStateChanged(
      function(firebaseUser) {
        unsubscribe();
        // Check if we are already signed-in Firebase with the correct user.
        if (!this.isUserEqual(googleUser, firebaseUser)) {
          // Build Firebase credential with the Google ID token.
          var credential = firebase.auth.GoogleAuthProvider.credential(
            googleUser.idToken,
            googleUser.accessToken
          );
          // Sign in with credential from the Google user.
          firebase
            .auth()
            .signInWithCredential(credential)
            .then(function(result) {
              console.log(
                'user signed in ' + result.additionalUserInfo.isNewUser
              );
              if (result.additionalUserInfo.isNewUser) {
                console.log(bankid);
              Promise.apply(  firebase
                  .database()
                  .ref('/users/' + result.user.uid)
                  .set({
                    gmail: result.user.email,
                    profile_picture: result.additionalUserInfo.profile.picture,
                    first_name: result.additionalUserInfo.profile.given_name,
                    last_name: result.additionalUserInfo.profile.family_name,
                    created_at: Date.now(),
                    eventuser:bankid,
                    welcome: '0',
                     notifications:[{
                      data:{
                       notificationid:0,
                        title:"Welcome to conneXt",
                      subtitle:"Hakuna Matata!!! Time for fun!!! let's gear up for 24th Sep",
                      eventtype:'N',
                      eventid:"N1"
                    }
                  }]
                  })
                  .then(function(snapshot) {
                     snapshot.get().then(function(doc) {
                console.log(doc.data().welcome.toString());
                });
                    console.log('Snapshot', snapshot);
                  }));
                   registerForPushNotificationsAsync();
                   sendPushNotification(result.user.uid);
                  Promise.apply( firebase.database.ref('users/' + result.user.uid)
                      .update({
                    welcome: '1',
                  })
                  );

              } else {
              Promise.apply(   firebase.database.ref('users/' + result.user.uid)
                  .update({
                    last_logged_in: Date.now(),
                  })
              );
              }
            })
            .catch(function(error) {
              // Handle Errors here.
              var errorCode = error.code;
              var errorMessage = error.message;
              // The email of the user's account used.
              var email = error.email;
              // The firebase.auth.AuthCredential type that was used.
              var credential = error.credential;
              // ...

              console.log(error);
            });
        } else {
          console.log('User already signed-in Firebase.');
        }
      }.bind(this)
    );
  };
  signInWithGoogleAsync = async (bankid) => {
    try {

      console.log(' calling signInWithGoogleAsync');
     var goodID="0";
      await firebase.database().ref('users/').orderByChild("eventuser").equalTo(bankid).on("child_added",function(data){
          console.log("testing "+data.val().userid);
          goodID="2"
          alert("This Number already Logged with " + data.val().gmail);
          return { cancelled: true };
        }. catch(
        function (error) {  
          console.log("Error: " + error.code);
      }));   
      
      await firebase.database().ref('bankusers/').orderByChild("userid").equalTo(bankid).on("child_added",function(data){
          console.log("testing "+data.val().userid);
          goodID="1"
        }, 
        function (error) {  
          console.log("Error: " + error.code);
      });   
      
      if(goodID=="0"){
        alert("Bad Identification \nContact App Owner");
        return { cancelled: true };
      }
      if(goodID=="2"){
        return { cancelled: true };
      }
      if(goodID==1){
        const result = await Google.logInAsync({
          behaviour: 'web',
          androidClientId:'528012979704-q3hlmjps8shf9b7j5okg5l2fjhhjgei5.apps.googleusercontent.com',
          iosClientId: '528012979704-ffpakqhbqltr5oaefngl714p0pk8on10.apps.googleusercontent.com', //enter ios client id
          scopes: ['profile', 'email'],
        });
      
        if (result.type === 'success') {
          console.log('Successful Login' + result.accessToken);
          this.onSignIn(result,bankid);
          return result.accessToken;
        } else {
          console.log('InSuccessful Login');
          return { cancelled: true };
        }
      }
    } catch (e) {
      console.log(e);
      return { error: true };
    }
  };
 handleBankUser(text){
   
   this.setState({ bankid :text})
 }
  render() {
    return (
    <Wallpaper >
    <View style={styles.container}><Logo/>
        <Text>Enter your ID:</Text>
        <TextInput
          style={styles.input}
          underlineColorAndroid ="transparent"
          placeholder="Enter 7 digit number..."
          placeholderTextColor ='#9a73ef"'
          onChangeText={bankid => this.setState({ bankid })}
          maxLength={100}
        />
        <TouchableHighlight onPress={() => {this.signInWithGoogleAsync(this.state.bankid)}}> 
       <Image source={require('../assets/sign_in.png')} 
        />
        </TouchableHighlight>
      
      </View>
      
      </Wallpaper>
    );
  }
}

export default LoginScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    height: 40,
    borderWidth: 1,
    margin: 8,
    padding: 8,
    width: '95%',
  }
});
