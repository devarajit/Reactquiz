import React from 'react';
import {
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Text,
  KeyboardAvoidingView,
  View,
} from 'react-native';


export default class ErrorScreen extends React.Component {

    render(){
        return(
            <View>
                <Text>Under Maintainence...</Text>
            </View>
        )
    }
}


